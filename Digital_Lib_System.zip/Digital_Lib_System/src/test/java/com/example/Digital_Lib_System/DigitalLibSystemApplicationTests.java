package com.example.Digital_Lib_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalLibSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
