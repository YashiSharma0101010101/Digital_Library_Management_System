package com.example.Digital_Lib_System.Models.Enums;

public enum TransactionStatus {
    PENDING, // intermediate state

    SUCCESS, // terminal state

    FAILED // terminal state
}
