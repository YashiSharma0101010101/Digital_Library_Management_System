package com.example.Digital_Lib_System.Models.Enums;

public enum Genre {
    FICTION,

    NON_FICTION,

    PROGRAMMING
}
