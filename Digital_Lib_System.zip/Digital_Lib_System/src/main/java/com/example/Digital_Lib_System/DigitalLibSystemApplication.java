package com.example.Digital_Lib_System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalLibSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalLibSystemApplication.class, args);
	}

}
