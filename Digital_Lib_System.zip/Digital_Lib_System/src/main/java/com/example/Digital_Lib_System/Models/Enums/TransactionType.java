package com.example.Digital_Lib_System.Models.Enums;

public enum TransactionType {
    ISSUE,

    RETURN
}
